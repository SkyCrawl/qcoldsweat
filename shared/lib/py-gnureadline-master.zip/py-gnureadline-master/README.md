# Stand-alone GNU readline module for python 2.x/3.x

Various platforms have different problems. For example, MacOS X doesn't ship with a python distribution containing a module for GNU readline. QNAP devices don't even ship with a python distribution and on top of that:

1. Third-party distributions do not contain the `readline` module.
2. Third-party package managers (e.g. [Entware-ng](https://github.com/Entware-ng/Entware-ng)) can not create static libraries as a fully featured native compiler is missing and [Ludwig Schwardt's python-gnureadline](https://github.com/ludwigschwardt/python-gnureadline) can not be used.

To avoid the hassle of cross compilation, this module is based on Ludwig Schwardt's module and intends to remedy all of the above conditions by linking to a shared (dynamic) library instead. As such, there are some limitations:
* The library must stay where it is (unless we re-install).
* Updating the library may break your python applications.
* Things will likely get complicated if you want to launch multiple python applications that require different versions of GNU readline.

Internally, the module is called `gnureadline` so there's no potential clash with the standard `readline` module (e.g. MacOS X that builds the `readline` module around the [editline](http://www.thrysoee.dk/editline/) library). Because of that, polite installers (e.g. `pip`) and shells like `IPython` are happy. However, you won't find this module in a public repository (like PyPI) yet, so you have to install manually:
```bash
# register the path to "libreadline.so" and "libhistory.so"
export RL_PATH=<path-to-gnu-readline-shared-library>
[sudo] python setup.py install
```

Windows users, please consider [pyreadline](http://pypi.python.org/pypi/pyreadline) instead - it is a pure Python readline replacement that interacts with the Windows clipboard.
