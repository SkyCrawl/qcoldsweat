#!/usr/bin/env python

##########
# IMPORTS
##########
import os
import sys
import subprocess
from distutils.command.build_ext import build_ext
from setuptools import setup, Extension

##########
# CONSTANTS AND FUNCTIONS
##########

# At present (October 2016), Entware-ng contains 'libreadline' v6.3-1 which is higher than 4.2 and we can enable all readline functionality. The following macros can be found in 'pyconfig.h.in' in the main directory of the Python tarball.
DEFINE_MACROS = [
    ('HAVE_RL_APPEND_HISTORY', None),
    ('HAVE_RL_CALLBACK', None),
    ('HAVE_RL_CATCH_SIGNAL', None),
    ('HAVE_RL_COMPLETION_APPEND_CHARACTER', None),
    ('HAVE_RL_COMPLETION_DISPLAY_MATCHES_HOOK', None),
    ('HAVE_RL_COMPLETION_MATCHES', None),
    ('HAVE_RL_COMPLETION_SUPPRESS_APPEND', None),
    ('HAVE_RL_PRE_INPUT_HOOK', None),
]

##########
# ENTRY POINT
##########

# Determine cooperation with distutils and check for quiet vs. verbose mode.
building = False
verbose = True
for s in sys.argv[1:]:
    if s.startswith('bdist') or s.startswith('build') or s.startswith('install'):
        building = True
    if s in ['--quiet', '-q']:
        verbose = False
    if s in ['--verbose', '-v']:
        verbose = True

# Determine the target 'readline.c'. Try version-specific source or fall back to major-only version.
source = os.path.join('Modules', '%d.%d' % sys.version_info[:2], 'readline.c')
if not os.path.exists(source):
    source = os.path.join('Modules', '%d.x' % sys.version_info[0], 'readline.c')

# Determine the shared library location.
rl_path=os.environ.get('RL_PATH', sys.path)

# Proceed to installation.    
setup(
    name="gnureadline",
    version="0.1",
    description="Standard Python 'readline' extension dynamically linked against a GNU readline shared library.",
    long_description="This module is based on 'https://github.com/ludwigschwardt/python-gnureadline' and should work for any limited environment where Python doesn't contain the 'readline' module by default, provided that a GNU readline shared library is available somewhere on the system. Use the 'RL_PATH' environment variable to specify the path, if it is not standard.",
    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: Console',
        'Intended Audience :: Developers',
        'Intended Audience :: End Users/Desktop',
    	'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
    	'Natural Language :: English',
    	'Operating System :: POSIX',
    	'Programming Language :: C',
    	'Programming Language :: Python :: 2',
    	'Programming Language :: Python :: 3',
    	'Topic :: Software Development :: Libraries :: Python Modules',
    ],
    author="Jiří Smolík",
    maintainer="Jiří Smolík",
    url="https://github.com/SkyCrawl/py-gnureadline-qnap",
    license="GNU GPL",
    platforms=['Posix'],
    include_package_data=True,
    py_modules=['readline'],
    cmdclass={'build_ext' : build_ext_subclass},
    ext_modules=[
        Extension(name="gnureadline",
			sources=[source],
			include_dirs=['.'],
			define_macros=DEFINE_MACROS,
			runtime_library_dirs=[rl_path],
			libraries=['ncurses, readline, history']
        ),
    ],
    zip_safe=False,
)
