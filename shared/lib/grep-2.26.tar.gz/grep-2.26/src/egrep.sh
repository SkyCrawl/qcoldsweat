#!@SHELL@
exec @grep@ @option@ "$@"
