#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Description: (Cold)sweat command-line utility

Copyright (c) 2013—2016 Andrea Peltrin
License: MIT (see LICENSE for details)
"""
from coldsweat.commands import run

if __name__ == '__main__':
    run()
